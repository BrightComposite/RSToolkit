//
//  Test_v3dot.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc.
//

#ifndef BulletTest_Test_v3dot_h
#define BulletTest_Test_v3dot_h

#ifdef __cplusplus
extern "C" { 
#endif

int Test_v3dot(void);

#ifdef __cplusplus
}
#endif

    
#endif
