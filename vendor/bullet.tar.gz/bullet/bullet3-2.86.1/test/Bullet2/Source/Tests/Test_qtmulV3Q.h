//
//  Test_qtmulV3Q.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc.
//

#ifndef BulletTest_Test_qtmulV3Q_h
#define BulletTest_Test_qtmulV3Q_h

#ifdef __cplusplus
extern "C" { 
#endif

int Test_qtmulV3Q(void);

#ifdef __cplusplus
}
#endif

    
#endif
