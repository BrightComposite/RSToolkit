/*
 *
 */

#ifndef PLATFORM_UTILS_H
#define PLATFORM_UTILS_H

#ifdef _MSC_VER

#define __sprintf(b, l, f, ...) sprintf_s(b, l + 1, f, __VA_ARGS__)
#define __snprintf(b, l, f, ...) _snprintf_s(b, l + 1, l, f, __VA_ARGS__)
#define __strcpy(d, l, s) strcpy_s(d, l + 1, s)
#define __wcscpy(d, l, s) wcscpy_s(d, l + 1, s)
#define __strncpy(d, l, s, n) strncpy_s(d, l + 1, s, n)
#define __wcsncpy(d, l, s, n) wcsncpy_s(d, l + 1, s, n)
#define __umask(n, o) _umask_s(n, o)
#define __snwprintf(b, s, c, f, ...) _snwprintf_s(b, s, c, f, __VA_ARGS__)

#define __wcstombs(conv, d, l, s, c) wcstombs_s(conv, d, l + 1, s, c)

#define __getenv(b, s, var) char * b = (char *)malloc(s + 1); if(_dupenv_s(&b, &s, var) != 0) { free(b); b = NULL; }
#define __freeenv(b) free(b)
#else

#define __sprintf(b, l, f, ...) sprintf(b, f, __VA_ARGS__)

#ifdef _WIN32
#define __snprintf(b, s, f, ...) _snprintf(b, s, f, __VA_ARGS__)
#else
#define __snprintf(b, s, f, ...) snprintf(b, s, f, __VA_ARGS__)
#endif

#define __strcpy(d, l, s) strcpy(d, s)
#define __wcscpy(d, l, s) wcscpy(d, s)
#define __strncpy(d, l, s, n) strncpy(d, s, n)
#define __wcsncpy(d, l, s, n) wcsncpy(d, s, n)
#define __umask(n, o) _umask(n)
#define __snwprintf(b, s, c, f, ...) _snwprintf(b, c, f, __VA_ARGS__)

#define __wcstombs(conv, d, l, s, c) wcstombs(d, s, c)

#define __getenv(b, s, var) const char * b = getenv(var)
#define __freeenv(b)

#endif

#endif // PLATFORM_UTILS_H