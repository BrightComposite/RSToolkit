//
//  Test_quat_aos_neon.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc., Inc.
//

#ifndef BulletTest_Test_quat_aos_neon_h
#define BulletTest_Test_quat_aos_neon_h

#ifdef __cplusplus
extern "C" { 
#endif
    
    int Test_quat_aos_neon(void);
    
#ifdef __cplusplus
}
#endif

#endif
