//
//  Test_v3triple.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc.
//

#ifndef BulletTest_Test_v3triple_h
#define BulletTest_Test_v3triple_h

#ifdef __cplusplus
extern "C" { 
#endif

int Test_v3triple(void);

#ifdef __cplusplus
}
#endif

    
#endif
