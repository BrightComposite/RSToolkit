//
//  Test_btDbvt.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc., Inc.
//

#ifndef BulletTest_Test_btDbvt_h
#define BulletTest_Test_btDbvt_h

#ifdef __cplusplus
extern "C" { 
#endif
    
    int Test_btDbvt(void);
    
#ifdef __cplusplus
}
#endif

#endif
