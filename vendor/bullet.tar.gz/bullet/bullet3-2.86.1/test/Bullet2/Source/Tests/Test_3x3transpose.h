//
//  Test_3x3transpose.h
//  BulletTest
//
//  Copyright (c) 2011 Apple Inc.
//

#ifndef BulletTest_Test_3x3transpose_h
#define BulletTest_Test_3x3transpose_h

#ifdef __cplusplus
extern "C" { 
#endif
    
    int Test_3x3transpose(void);
    
#ifdef __cplusplus
}
#endif


#endif
